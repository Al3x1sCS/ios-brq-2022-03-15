//
//  TabelaViewController.swift
//  Layout
//
//  Created by user210587 on 3/22/22.
//

import UIKit

class tabelaViewController : UITableViewController {
    
    let pizzas : [String] = ["Mussarela", "Calabreza", "Palmito"]
    let descricaoPizzas = ["", "", ""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    //numero de colunas da lista
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    //quantidade de pizzas
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzas.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celula = tableView.dequeueReusableCell(withIdentifier: "celulaReuso", for: indexPath)
        celula.textLabel?.text = pizzas[indexPath.row]
        return celula
    }
}
